package com.example.sapaan

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.WindowManager

class GreetingActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply {
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        hideSystemBars()

        val (top, bottom) = Greeting.background()
        val view = GreetingView(this, Greeting.text(), Greeting.LINE2, top, bottom)
        view.onDismiss = {
            finish()
            overridePendingTransition(0, 0)
        }
        setContentView(view)
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    // Kalau layar mati / pindah app, tutup supaya animasi berikutnya mulai dari awal
    override fun onStop() {
        super.onStop()
        finish()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        finish()
    }
}
