package com.example.sapaan

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

class GreetingView(
    context: Context,
    private val line1: String,
    private val line2: String,
    private val bgTop: Int,
    private val bgBottom: Int
) : View(context) {

    var onDismiss: (() -> Unit)? = null

    // Linimasa animasi (ms)
    private val startDelay = 600L
    private val msChar1 = 85L
    private val pause = 400L
    private val msChar2 = 60L
    private val typingEnd = startDelay + line1.length * msChar1 + pause + line2.length * msChar2
    private val readyAt = typingEnd + 600L
    private val shimmerPeriod = 1400L

    private var t0 = 0L
    private var ready = false

    private fun makePaint(bold: Boolean) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    private val bgPaint = Paint()
    private val base1 = makePaint(true)
    private val base2 = makePaint(false)
    private val fx1 = makePaint(true)
    private val fx2 = makePaint(false)
    private val hintPaint = makePaint(false)
    private val chevron = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFD54F.toInt() }
    private val starPath = Path()
    private val shaderMatrix = Matrix()
    private var rainbow: LinearGradient? = null

    // Gradasi pelangi transparan (ujung-ujungnya bening)
    private val rainbowColors = intArrayOf(
        0x00FFFFFF,
        0xCCFF4D4D.toInt(),
        0xCCFFA94D.toInt(),
        0xCCFFE44D.toInt(),
        0xCC5CE65C.toInt(),
        0xCC4DC3FF.toInt(),
        0xCC8A6BFF.toInt(),
        0xCCFF6BD6.toInt(),
        0x00FFFFFF
    )

    private var x1 = 0f
    private var x2 = 0f
    private var y1 = 0f
    private var y2 = 0f
    private var starR = 0f

    private fun fit(text: String, p: Paint, start: Float, maxW: Float): Float {
        p.textSize = start
        val m = p.measureText(text)
        return if (m > maxW) start * maxW / m else start
    }

    private fun buildStar(r: Float) {
        starPath.reset()
        for (i in 0 until 10) {
            val rad = if (i % 2 == 0) r else r * 0.45f
            val a = -PI / 2 + i * PI / 5
            val x = (cos(a) * rad).toFloat()
            val y = (sin(a) * rad).toFloat()
            if (i == 0) starPath.moveTo(x, y) else starPath.lineTo(x, y)
        }
        starPath.close()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        bgPaint.shader = LinearGradient(0f, 0f, 0f, hf, bgTop, bgBottom, Shader.TileMode.CLAMP)

        base1.textSize = fit(line1, base1, wf * 0.12f, wf * 0.66f)
        base2.textSize = fit(line2, base2, wf * 0.06f, wf * 0.84f)
        fx1.textSize = base1.textSize
        fx2.textSize = base2.textSize
        base1.setShadowLayer(wf * 0.025f, 0f, 0f, 0x99FFFFFF.toInt())
        base2.setShadowLayer(wf * 0.015f, 0f, 0f, 0x66FFFFFF.toInt())
        hintPaint.textSize = wf * 0.04f
        chevron.strokeWidth = wf * 0.009f

        x1 = (wf - base1.measureText(line1)) / 2f
        x2 = (wf - base2.measureText(line2)) / 2f
        y1 = hf * 0.42f
        y2 = y1 + base1.textSize * 1.05f

        starR = base1.textSize * 0.42f
        starPaint.setShadowLayer(starR * 0.7f, 0f, 0f, 0xAAFFD54F.toInt())
        buildStar(starR)

        rainbow = LinearGradient(0f, 0f, wf * 0.55f, 0f, rainbowColors, null, Shader.TileMode.CLAMP)
        fx1.shader = rainbow
        fx2.shader = rainbow
    }

    private fun easeOutBack(x: Float): Float {
        val c1 = 1.70158f
        val c3 = c1 + 1f
        return 1f + c3 * (x - 1f).pow(3) + c1 * (x - 1f).pow(2)
    }

    override fun onDraw(c: Canvas) {
        if (t0 == 0L) t0 = SystemClock.uptimeMillis()
        val t = SystemClock.uptimeMillis() - t0
        val w = width.toFloat()
        val h = height.toFloat()

        c.drawRect(0f, 0f, w, h, bgPaint)

        // Kilatan pelangi: pita miring yang menyapu dari kiri ke kanan, berulang
        val tt = (t - startDelay).coerceAtLeast(0L)
        val band = w * 0.55f
        val phase = (tt % shimmerPeriod).toFloat() / shimmerPeriod
        shaderMatrix.reset()
        shaderMatrix.setRotate(18f)
        shaderMatrix.postTranslate(-band + (w + band * 2f) * phase, 0f)
        rainbow?.setLocalMatrix(shaderMatrix)

        // Berapa huruf yang sudah muncul (pecahan = huruf yang sedang "pop")
        val r1 = min(tt.toFloat() / msChar1, line1.length.toFloat())
        val tt2 = tt - line1.length * msChar1 - pause
        val r2 = if (tt2 <= 0L) 0f else min(tt2.toFloat() / msChar2, line2.length.toFloat())

        drawStar(c, t)
        drawTyped(c, line1, r1, x1, y1, base1, fx1)
        drawTyped(c, line2, r2, x2, y2, base2, fx2)

        if (t >= readyAt) {
            ready = true
            val a = ((t - readyAt) / 500f).coerceIn(0f, 1f)
            val pulse = 0.65f + 0.35f * sin(t / 300f)
            val bounce = sin(t / 260f) * h * 0.008f
            val label = "Geser ke atas"
            hintPaint.alpha = (255 * a * pulse).toInt()
            c.drawText(label, (w - hintPaint.measureText(label)) / 2f, h * 0.9f, hintPaint)
            chevron.alpha = (255 * a).toInt()
            val s = w * 0.04f
            val cx = w / 2f
            val cy = h * 0.9f - hintPaint.textSize * 2.2f + bounce
            c.drawLines(
                floatArrayOf(
                    cx - s, cy + s * 0.5f, cx, cy - s * 0.5f,
                    cx, cy - s * 0.5f, cx + s, cy + s * 0.5f
                ),
                chevron
            )
        }

        postInvalidateOnAnimation()
    }

    private fun drawStar(c: Canvas, t: Long) {
        val appear = (t / 700f).coerceIn(0f, 1f)
        val s = easeOutBack(appear) * (1f + 0.08f * sin(t / 280f))
        val rot = (1f - appear) * -300f + 10f * sin(t / 450f)
        c.save()
        c.translate(x1 - starR * 1.8f, y1 - base1.textSize * 0.33f)
        c.rotate(rot)
        c.scale(s, s)
        c.drawPath(starPath, starPaint)
        c.restore()
    }

    private fun drawTyped(c: Canvas, text: String, revealed: Float, x: Float, y: Float, base: Paint, fx: Paint) {
        val full = revealed.toInt().coerceIn(0, text.length)
        val frac = (revealed - full).coerceIn(0f, 1f)

        val prefix = text.substring(0, full)
        if (prefix.isNotEmpty()) {
            c.drawText(prefix, x, y, base)
            c.drawText(prefix, x, y, fx)
        }

        if (full < text.length && frac > 0f) {
            val prefixW = base.measureText(prefix)
            val ch = text[full].toString()
            val chW = base.measureText(ch)
            val e = easeOutBack(frac)
            c.save()
            c.translate(x + prefixW + chW / 2f, y + (1f - e) * base.textSize * 0.3f)
            val s = 0.4f + 0.6f * e
            c.scale(s, s)
            base.alpha = (255 * frac).toInt()
            c.drawText(ch, -chW / 2f, 0f, base)
            base.alpha = 255
            c.restore()
        }
    }

    // Tarik ke atas setelah animasi selesai
    private var downY = 0f
    private var downTime = 0L

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!ready) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downY = e.rawY
                downTime = e.eventTime
            }
            MotionEvent.ACTION_MOVE -> {
                translationY = (e.rawY - downY).coerceAtMost(0f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val dy = e.rawY - downY
                val quick = e.eventTime - downTime < 300L && dy < -height * 0.08f
                if (dy < -height * 0.22f || quick) {
                    animate().translationY(-height.toFloat()).setDuration(200L)
                        .withEndAction { onDismiss?.invoke() }.start()
                } else {
                    animate().translationY(0f).setDuration(180L).start()
                }
            }
        }
        return true
    }
}
