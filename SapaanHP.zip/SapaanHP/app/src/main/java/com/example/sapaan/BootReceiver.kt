package com.example.sapaan

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        try {
            if (i.action == Intent.ACTION_BOOT_COMPLETED && Prefs.enabled(c)) {
                c.startForegroundService(Intent(c, GreetingService::class.java))
            }
        } catch (_: Exception) {
        }
    }
}
