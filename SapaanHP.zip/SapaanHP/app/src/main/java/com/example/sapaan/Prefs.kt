package com.example.sapaan

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("sapaan", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    // true  = tampil setelah kunci layar dibuka
    // false = tampil begitu layar menyala
    fun afterUnlock(c: Context) = sp(c).getBoolean("after_unlock", true)
    fun setAfterUnlock(c: Context, v: Boolean) = sp(c).edit().putBoolean("after_unlock", v).apply()
}
