package com.example.sapaan

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        root.addView(TextView(this).apply {
            text = "Sapaan HP"
            textSize = 26f
        })
        status = TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(12), 0, dp(12))
        }
        root.addView(status)

        root.addView(button("1. Izinkan tampil di atas aplikasi lain") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("2. Izinkan notifikasi") {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        })
        root.addView(button("3. Matikan penghemat baterai untuk app ini") { askBattery() })

        root.addView(Switch(this).apply {
            text = "Tampil setelah kunci dibuka (matikan = tampil saat layar menyala)"
            isChecked = Prefs.afterUnlock(this@MainActivity)
            setPadding(0, dp(16), 0, dp(16))
            setOnCheckedChangeListener { _, checked -> Prefs.setAfterUnlock(this@MainActivity, checked) }
        })

        root.addView(button("Aktifkan") {
            Prefs.setEnabled(this, true)
            startForegroundService(Intent(this, GreetingService::class.java))
            refresh()
        })
        root.addView(button("Matikan") {
            Prefs.setEnabled(this, false)
            stopService(Intent(this, GreetingService::class.java))
            refresh()
        })
        root.addView(button("Coba animasi sekarang") {
            startActivity(Intent(this, GreetingActivity::class.java))
        })

        setContentView(ScrollView(this).apply { addView(root) })

        if (Prefs.enabled(this)) {
            startForegroundService(Intent(this, GreetingService::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val overlay = if (Settings.canDrawOverlays(this)) "✅ aktif" else "❌ belum"
        val svc = if (Prefs.enabled(this)) "✅ menyala" else "⛔ mati"
        status.text = "Izin tampil di atas app lain: $overlay\nLayanan sapaan: $svc"
    }

    @SuppressLint("BatteryLife")
    private fun askBattery() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        }
    }
}
