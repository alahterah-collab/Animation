package com.example.sapaan

import java.util.Calendar

object Greeting {
    const val LINE2 = "Semoga harimu menyenangkan"

    private fun hour() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    fun text(): String = when (hour()) {
        in 4..10 -> "Selamat pagi"
        in 11..14 -> "Selamat siang"
        in 15..17 -> "Selamat sore"
        else -> "Selamat malam"
    }

    /** Warna latar atas -> bawah, menyesuaikan waktu. */
    fun background(): Pair<Int, Int> = when (hour()) {
        in 4..10 -> 0xFFFF9966.toInt() to 0xFF3A6FD8.toInt()
        in 11..14 -> 0xFF2D9CDB.toInt() to 0xFF1B4F9C.toInt()
        in 15..17 -> 0xFFFF7E5F.toInt() to 0xFF5B2A86.toInt()
        else -> 0xFF0F1630.toInt() to 0xFF2B1B54.toInt()
    }
}
